<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>user::Plugin</name>
    <message>
        <source>ID_USER_COMPONENT_INDICATOR_NAME</source>
        <translation>Indicator Component</translation>
    </message>
    <message>
        <source>ID_USER_COMPONENT_INDICATOR_DESCRIPTION</source>
        <translation>This is a sample component that can be added to entities inside the editor. It creates a colorful box around the entity.</translation>
    </message>
    <message>
        <source>ID_USER_COMPONENT_INDICATOR_COLOR_DESCRIPTION</source>
        <translation>Select a color for the indicator</translation>
    </message>
</context>
</TS>
