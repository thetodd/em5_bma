<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>flo11::BMAFireEvent</name>
    <message>
        <source>ID_RESET_BMA_OBJECTIVE_TEXT</source>
        <translation>BMA zurücksetzen</translation>
    </message>
    <message>
        <source>ID_BMA_FIRE_EVENT_NAME</source>
        <translation>BMA</translation>
    </message>
</context>
<context>
    <name>flo11::TriggerBMAEventCommand</name>
    <message>
        <source>ID_CMD_TRIGGER_BMA_EVENT</source>
        <translation>BMA zur Probe auslösen</translation>
    </message>
</context>
</TS>
