﻿<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de">
<context>
	<name>infotexts</name>
	<message>
		<source>ID_NAME_KDOW</source>
		<translation>Kommandowagen</translation>
	</message>
	<message>
		<source>ID_NAME_FIREFIGHTER_LEADER</source>
		<translation>Gruppenführer</translation>
	</message>
</context>
</TS>