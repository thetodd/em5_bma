﻿<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de">
<context>
	<name>flo11::BMAFireEvent</name>
	<message>
		<source>ID_BMA_FIRE_EVENT_NAME</source>
		<translation>BMA</translation>
	</message>
	<message>
        <source>ID_RESET_BMA_OBJECTIVE_TEXT</source>
        <translation>BMA zurücksetzen</translation>
    </message>
</context>
</TS>